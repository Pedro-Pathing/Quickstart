package org.firstinspires.ftc.teamcode.pedroPathing.Hardware;

class Camera {
    public:
    Camera() {
        // initialisation de la caméra, pipeline, etc.
    }

    void update() {
        // Récupère les données de vision
        // Exemple : distance, offset horizontal, vertical, etc.
        // Calcule les 3 valeurs utiles
        computeShooterSpeed();
        computeShooterAngle();
        computeTurretRotation();
    }

    boolean hasTarget() const {
        return targetVisible;
    }

    float getShooterSpeed() const {
        return shooterSpeed;
    }

    float getShooterAngle() const {
        return shooterAngle;
    }

    float getTurretRotation() const {
        return turretRotation;
    }

    private:
    boolean targetVisible = false;

    float shooterSpeed = 0.0f;
    float shooterAngle = 0.0f;
    float turretRotation = 0.0f;

    void computeShooterSpeed() {
        // Exemple : shooterSpeed = f(distance)
    }

    void computeShooterAngle() {
        // Exemple : shooterAngle = f(distance)
    }

    void computeTurretRotation() {
        // Exemple : turretRotation = offsetHorizontal
    }
};
